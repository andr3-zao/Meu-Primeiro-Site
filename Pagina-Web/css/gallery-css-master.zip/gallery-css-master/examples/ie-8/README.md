# Gallery-css and oldIE

Gallery-css is absolutely achievable in IE8, this example is designed to serve as a few hints for how you can achieve that goal. 

Auto-playing / animation is not possible, so if thats a deal breaker, you'll need to go back to using a javascript based image gallery. 